package com.example.chenkunyao.ckysoftapdemo.tools;

public class SmartlinkInfo {
	public String ssid = null;
	public String password = null;
	public int random = 0;
	public int wlansecurity = 0;
	public String senderip = null;
	public int senderport = 0;
	public int protocol = 0;
}
